package com.ciber13.calculator13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Calculator13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
