package com.ciber13.calculator13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Calculator13Application {

	public static void main(String[] args) {
		SpringApplication.run(Calculator13Application.class, args);
	}

}
